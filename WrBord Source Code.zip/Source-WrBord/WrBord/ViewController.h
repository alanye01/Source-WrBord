//
//  ViewController.h
//  WrBord
//
//  Created by Alan Ye on 2018/4/19.
//  Copyright © 2018 Alan Ye. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController


@end

