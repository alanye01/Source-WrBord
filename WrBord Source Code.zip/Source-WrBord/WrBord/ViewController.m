//
//  ViewController.m
//  WrBord
//
//  Created by Alan Ye on 2018/4/19.
//  Copyright © 2018 Alan Ye. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}


@end
