//
//  main.m
//  WrBord
//
//  Created by Alan Ye on 2018/4/19.
//  Copyright © 2018 Alan Ye. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
